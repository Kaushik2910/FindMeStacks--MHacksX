
package com.example.prats.findmestats;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.*;

import java.io.*;

public class HackKingsAPIReader extends AsyncTask<String, Void, String> {
    String[] display;
    double[] averagePrice;
    invest invest;

    public  HackKingsAPIReader(String[] display, double[] averagePrice, invest invest) {
        super();
        this.display = display;
        this.averagePrice = averagePrice;
        this.invest = invest;
    }

    protected String doInBackground(String... identifiers) {
        try {
            String urlString = "https://www.blackrock.com/tools/hackathon/performance";
            urlString += "?identifiers=";
            for (int i = 0; i < identifiers.length; i++) {
                urlString += identifiers[i];
                if (i != identifiers.length - 1) {
                    urlString += ",";
                }
            }
            URL url = new URL(urlString);
            URLConnection urlConnection = url.openConnection();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String inputLine;
            StringBuilder sb = new StringBuilder();

            while ((inputLine = bufferedReader.readLine()) != null) {
                sb.append(inputLine + "\n");
            }

            String jsonString = sb.toString();
            bufferedReader.close();



            return jsonString;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    protected void onPostExecute(String jsonString) {
        double[] riskValues = new double[20];
        try {
            riskValues = getRiskFromJSON(jsonString);
        } catch (Exception e) {
            e.printStackTrace();
        }

        double temp = 0.000;
        String temp2;
        double temp3;
        for (int i = 0; i < 20; i++) {
            for (int j = 1; j < 20; j++) {
                if (riskValues[j - 1] > riskValues[j]) {
                    temp = riskValues[j - 1];
                    temp2 = display[j - 1];
                    temp3 = averagePrice[j-1];
                    riskValues[j - 1] = riskValues[j];
                    display[j - 1] = display[j];
                    averagePrice[j-1] = averagePrice[j];
                    riskValues[j] = temp;
                    display[j] = temp2;
                    averagePrice[j] = temp3;

                }
            }
        }


        invest.changeActivity(riskValues);

    }

    private double[] getRiskFromJSON(String jsonString) throws JSONException {
        JSONObject response = new JSONObject(jsonString);
        JSONObject resultMap = response.getJSONObject("resultMap");
        JSONArray returns = resultMap.getJSONArray("RETURNS");
        int lengthOfReturns = returns.length();
        double[] riskValues = new double[lengthOfReturns];

        for (int i = 0; i < lengthOfReturns; i++) {
            JSONObject stockReturn = returns.getJSONObject(i);
            JSONObject latestPerf = stockReturn.getJSONObject("latestPerf");
            double oneYearRisk = latestPerf.getDouble("oneYearRisk");
            riskValues[i] = oneYearRisk;
        }

        return riskValues;

    }
}
