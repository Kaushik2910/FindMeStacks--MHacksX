package com.example.prats.findmestats;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.net.ssl.HttpsURLConnection;

public class invest extends AppCompatActivity {

    public double[] riskValues = new double[20];
    public double totalOne;
    public double[] averagePrice = {910.98,150.02,155.03,78.99,81.76,155.18,47.36,114.69,69.94,55.34,38.78,11.32,152.25,107.31,76.41,80.75,47.17,165.00,109.46,225.61};
    public String[] display = {"GOOG","AAPL","FB","CVS","WBA","IBM","MET","PEP","MSFT","NKE","T","F","HD","CVX","WMT","XOM","ORCL","COST","UPS","GS"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invest);


        final EditText percentage = (EditText) findViewById(R.id.invest_Edit_Text);
        Button nextButton = (Button) findViewById(R.id.invest_next_button);

        final invest self = this;

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double available, net = 0.00;

                Bundle bundle = getIntent().getExtras();
                available = bundle.getDouble("AVAILABLE");

                Double percentageDouble = Double.parseDouble(percentage.getText().toString());
                Log.d("INVEST QUESTION", percentage.toString());
               // Intent intent = new Intent(invest.this, result.class);
                //intent.putExtra("INVEST PERCENTAGE", percentageDouble);
                //startActivity(intent);

                net = available * (percentageDouble / 100);
                totalOne = net;

                HackKingsAPIReader blackrockAPI = new HackKingsAPIReader(display, averagePrice, self);
                try {
                    blackrockAPI.execute("GOOG,AAPL,FB,CVS,WBA,IBM,MET,PEP,MSFT,NKE,T,F,HD,CVX,WMT,XOM,ORCL,COST,UPS,GS");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void changeActivity(double[] riskValues) {
        Bundle bundle5 = new Bundle();
        bundle5.putDoubleArray("AVERAGE_PRICE", averagePrice);
        bundle5.putStringArray("DISPLAY", display);
        bundle5.putDoubleArray("RISK_VALUES", riskValues);
        bundle5.putDouble("TOTAL_ONE", totalOne);
        Intent intent = new Intent(invest.this, result.class);
        intent.putExtras(bundle5);

        startActivity(intent);
    }
}









