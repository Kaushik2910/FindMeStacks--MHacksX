package com.example.prats.findmestats;

import android.content.Intent;
import android.renderscript.Double3;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ListView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.List;

public class result extends AppCompatActivity {

    private ArrayAdapter<String> adapter;
    private List<String> liste;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Bundle bundle = getIntent().getExtras();

        double[] averagePrice = bundle.getDoubleArray("AVERAGE_PRICE");
        String[] display = bundle.getStringArray("DISPLAY");
        double[] riskValues = bundle.getDoubleArray("RISK_VALUES");
        double totalOne = bundle.getDouble("TOTAL_ONE");

        double[] averagePrice1 = new double[20];
        String[] display1 = new String[20];
        double[] riskValues1 = new double[20];



        double[] possibleLoss = new double[20];
        for(int m=0;m<20;m++){

            possibleLoss[m]=riskValues[m]*totalOne;
        }

        int k,n;
        for(n=0,k=0;n<20;n++){
            if((totalOne-possibleLoss[n])>averagePrice[n]) {

                averagePrice1[k] = averagePrice[n];
                display1[k] = display[n];
                riskValues1[k++] = riskValues[n];
            }

        }



        TextView textView = (TextView) findViewById(R.id.textView11);
        String print;

        for(int z=1;z<=k;z++){

            print = Integer.toString(z)  + "  " +display1[z] +"    "+ Double.toString(averagePrice1[z]) +"    "+ Double.toString(riskValues1[z]);
            textView.setText("Company Name" + print);

        }





    }

}


/*
TextView textView = (TextView) findViewById(R.id.textView4_Text_View);
        TextView textView2 = (TextView) findViewById(R.id.textView4);
        textView.setText("Your tax is: " + Double.toString(tax));
        textView2.setText("Your Net Income is: " + Double.toString(available));
 */





